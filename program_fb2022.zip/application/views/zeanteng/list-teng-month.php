<div class="row bg-purple fc-white" style="padding:10px;">
  <div class="col-1 d-none d-sm-block text-center">เวลา</div>
  <div class="col-3 text-center">เจ้าบ้าน</div>
  <div class="col-1 text-center"></div>
  <div class="col-3 text-center">ทีมเยือน</div>
  <div class="col-2 text-center">คุณเลือก</div>
  <div class="col-1 text-center">ผล</div>
  <div class="col-1 text-center"></div>
</div>
<?php $matchdate = ''; foreach($rs_teng->result() as $row) { ?>
<?php if($matchdate!=$row->matchdate){ ?>
<div class="row" style="padding:10px; background-color: #b8e5fe;">
<?php echo $row->matchdate ?>
</div>
<?php } ?>
<div class="row" style="padding:10px">
  <div class="col-1 d-none d-sm-block text-center"><?php echo $row->matchtime ?></div>
  <div class="col-3 text-center"><?php echo $row->club_home_name ?></div>
  <div class="col-1 text-center">vs</div>
  <div class="col-3 text-center"><?php echo $row->club_away_name ?></div>
  <div class="col-2 text-center"><span class="badge badge-primary">
  <?php //echo ($row->teng_predict=='h')?$row->club_home_name:$row->club_away_name ?>
  <?php if($row->teng_predict=='h'){ echo 'เจ้าบ้าน';}elseif($row->teng_predict=='a'){echo 'ทีมเยือน';}else{echo 'เสมอ';} ?>
  </span></div>  
  <div class="col-1 text-center"><?php echo ($row->match_score_status=='n')?'? - ?':$row->club_home_score.' - '.$row->club_away_score ?></div>
  <div class="col-1 text-center"><div class="<?php echo ($row->match_score_status=='n')?'?':score_color($row->teng_score) ?>"><?php echo ($row->match_score_status=='n')?'?':floatval($row->teng_score) ?></div></div>
</div>
<?php $matchdate = $row->matchdate; } ?>