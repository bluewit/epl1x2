<div class="row" style="margin-top:15px">
  <div class="col">
    <h4>อันดับ เซียน</h4>
  </div>
</div>
<!-- END Row -->

<div class="row">
	<div class="col">                                     
        <table class="table table-striped table-bordered table-hover" id="datatables" width="100%">
          <thead>
            <tr role="row">
              <th width="5%">อันดับ</th>
              <th width="60%">ชื่อ</th>
              <th width="10%">คะแนน</th>
              <th width="20%"></th>
            </tr>
          </thead>
            <tbody>
            </tbody>
        </table> 
    </div>                                    
</div>
<!-- END Row -->

<!-- Modal -->
<div class="modal fade" id="list-month-teng" tabindex="-1" role="dialog" aria-labelledby="list-month-teng" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="price">รายการที่เล่น</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body" style="font-size:80%;">
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    </div>
  </div>
</div>
</div>
<!-- end Modal -->

<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var t = $('#datatables').DataTable({
			"bPaginate": true, 
			"bLengthChange": false, //+ แสดงจำนวนต่อหน้า
			"bFilter": false, //+ ช่องค้นหา
			"bInfo": false, //+ รายละเอียดจำนวนแถว
            "bProcessing": true,
            "bServerSide": true,
            "sServerMethod": "GET",
            "sAjaxSource": '<?php echo base_url('zeanteng/list-zean-all'); ?>',
            "iDisplayLength": 50,
			"columnDefs": [  //+ เงื่อนไขสำหรับปิดคอลัมภ์ที่ไม่ต้องการให้ค้นหา หรือ Sort
				{"searchable": true, "orderable": false, "targets":0,'className':'text-center'},
				{"targets":[1,2],'className':'text-center'},
				{"searchable": false, "orderable": false,"targets":3,'className':'text-center',
					"render": function(data, type, row) { // Available data available for you within the row
						var x = '<a href="" data-toggle="modal" data-target="#list-month-teng" data-id="'+data+'" title="ดูรายการที่เล่น"> ดูรายการที่เล่น</a>';
						return x;
					}
				}
			],
			"order": [2, 'desc'] //+ คอลัมภ์ที่ต้องการให้เรียงลำดับ
        });
		
		$('#list-month-teng').on('show.bs.modal', function (e) {
			$(this).find('.modal-body').html('<center><img src="<?php echo base_url('images/ajax-loader.gif') ?>"></center>').delay(1000).load('<?php echo site_url('zeanteng/list-teng-month')?>/'+$(e.relatedTarget).attr('data-id'));
		});
    });
</script>