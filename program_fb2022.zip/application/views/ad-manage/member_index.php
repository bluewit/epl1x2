<div class="">
  <div class="page-header-title">
    <h4 class="page-title">สมาชิก</h4>
  </div>
</div>

<div class="page-content-wrapper ">

    <div class="container">
    	<div class="row">                                     
            <div class="col-sm-12 col-md-12">
                <div class="panel">
                    <div class="panel-body">
                    	<form action="" method="post" id="form-search-top" class="form-inline">
                        <input type="button" onclick="getdate('week')" value="ทั้งสัปดาห์" />
                        <input type="button" onclick="getdate('month')" value="ทั้งเดือน" />
                        <input type="text" id="startdate" name="startdate" value="<?php echo $startdate ?>" required="required" />
                        <label>:</label>
                        <input type="text" id="enddate" name="enddate" value="<?php echo $enddate ?>" required="required" />                
                        <button type="submit" id="search-top" class="btn btn-success"><!--<i class="ti-search"></i>--> ค้นหา</button>
                        </form>
                    </div>
                </div>
            </div>                                     
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <h4 class="m-t-0">รายการสมาชิกและคะแนน</h4>
						<table class="table table-striped table-bordered table-hover display" id="datatables" width="100%">
                          <thead>
                            <tr role="row">
                              <th width="5%"></th>	
                              <th width="30%">ชื่อ</th>
                              <th width="30%">จำนวนคู่ที่เล่น</th>
                              <th width="30%">คะแนน</th>
                              <!--<th class="text-center" width="5%"></th>-->
                            </tr>
                          </thead>
                            <tbody>
								<?php if ($rs_members->num_rows() > 0) { $i=1;?>
                                <?php foreach($rs_members->result() as $row){ ?>
                                <tr align="center">
                                <td><?php echo $i++ ?></td>
                                <td><?php echo $row->nickname ?></td>
                                <td><?php echo $row->teng_match ?></td>
                                <td><?php echo $row->teng_score ?></td>
                                </tr>
                                <?php } ?>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

    </div><!-- container -->
</div> <!-- Page content Wrapper -->

<!-- END Row -->
<script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        $('table.display').DataTable({
			"bPaginate": false, 
			"bLengthChange": false,
			"bFilter": true,
			"bInfo": false,
			"bAutoWidth": false,
			//"ordering": false,
			"order": [1, 'asc'],
			"language": {
			  "emptyTable": "ไม่มีรายการ",
			  "sSearch": "ค้นหา : "
			}
		});		
    });
	function getdate(option) {
		var startdate = new Date();
		var enddate = new Date();				
		switch(option){
			case 'today':
				startdate.setDate(startdate.getDate() -1);
			break;
			case 'yesterday':
				startdate.setDate(startdate.getDate() -2);
				enddate.setDate(enddate.getDate() -1);
			break;
			case 'week':
				startdate.setDate(startdate.getDate() -7);
			break;
			case 'month':
				startdate.setDate(startdate.getDate() -30);
			break;
		}
		var sm = startdate.getMonth() + 1;
		var em = enddate.getMonth() + 1;
		var start = startdate.getFullYear() + '-' + sm+ '-' + ("0" + startdate.getDate()).slice(-2) +' 08:59:59';
		var end = enddate.getFullYear() + '-' + em+ '-' + ("0" + enddate.getDate()).slice(-2) +' 09:00:00';		
		$('#startdate').val(start);
		$('#enddate').val(end);
	}
</script>