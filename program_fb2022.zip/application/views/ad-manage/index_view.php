<div class="">
  <div class="page-header-title">
    <h4 class="page-title">หน้าแรก Admin</h4>
  </div>
</div>
<div class="page-content-wrapper ">
  <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="panel">
                <div class="panel-body">
                    <h1>Hello Admin </h1>
                    <!--<a href="<?php echo site_url('table-score/auto-update') ?>" target="_blank" class="btn btn-default"><i class="cus-table"></i> ปรับปรุงตารางคะแนนหน้าเว็บ</a>
                    <a href="<?php echo site_url('shooter/auto-update') ?>" target="_blank" class="btn btn-default"><i class="cus-table"></i> ปรับปรุงตารางดาวซัลโว</a>-->
               </div>
           </div>
        </div>
    </div><!-- row -->
  </div><!-- container -->     
</div>
<!-- Page content Wrapper -->