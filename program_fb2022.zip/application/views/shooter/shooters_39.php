<table class="shooter">
						<thead>
							<tr>
								<td class="tb_rank">ลำดับ</td>
								<td class="tb_player">นักฟุตบอล</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_total">รวม(จุดโทษ)</td>
							</tr>
						</thead>
						<tbody><tr>
						<td class="tb_rank"></td>
						<td class="tb_player"></td>
						<td class="tb_team"></td>
						<td class="tb_point"></td>
					</tr></tbody></table>