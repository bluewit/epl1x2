<table class="shooter">
						<thead>
							<tr>
								<td class="tb_rank">ลำดับ</td>
								<td class="tb_player">นักฟุตบอล</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_total">รวม(จุดโทษ)</td>
							</tr>
						</thead>
						<tbody><tr>
						<td class="tb_rank"> 1</td>
						<td class="tb_player">Mauro Emanuel Icardi Rivero</td>
						<td class="tb_team">Inter Milan</td>
						<td class="tb_point">29(6)</td>
					</tr><tr>
						<td class="tb_rank">2</td>
						<td class="tb_player">Ciro Immobile</td>
						<td class="tb_team">Lazio</td>
						<td class="tb_point">29(7)</td>
					</tr><tr>
						<td class="tb_rank">3</td>
						<td class="tb_player">Paulo Bruno Exequiel Dybala</td>
						<td class="tb_team">Juventus</td>
						<td class="tb_point">22(3)</td>
					</tr><tr>
						<td class="tb_rank">4</td>
						<td class="tb_player">Fabio Quagliarella</td>
						<td class="tb_team">Sampdoria</td>
						<td class="tb_point">19(7)</td>
					</tr><tr>
						<td class="tb_rank">5</td>
						<td class="tb_player">Dries Mertens</td>
						<td class="tb_team">Napoli</td>
						<td class="tb_point">18(4)</td>
					</tr><tr>
						<td class="tb_rank">6</td>
						<td class="tb_player">Edin Dzeko</td>
						<td class="tb_team">AS Roma</td>
						<td class="tb_point">16</td>
					</tr><tr>
						<td class="tb_rank">7</td>
						<td class="tb_player">Gonzalo Gerardo Higuain</td>
						<td class="tb_team">Juventus</td>
						<td class="tb_point">16(1)</td>
					</tr><tr>
						<td class="tb_rank">8</td>
						<td class="tb_player">Giovanni Pablo Simeone Baldini</td>
						<td class="tb_team">Fiorentina</td>
						<td class="tb_point">14</td>
					</tr><tr>
						<td class="tb_rank">9</td>
						<td class="tb_player">Sergej Milinkovic Savic</td>
						<td class="tb_team">Lazio</td>
						<td class="tb_point">12</td>
					</tr><tr>
						<td class="tb_rank">9</td>
						<td class="tb_player">Kevin Lasagna</td>
						<td class="tb_team">Udinese</td>
						<td class="tb_point">12</td>
					</tr></tbody></table>