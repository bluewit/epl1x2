<table class="shooter">
						<thead>
							<tr>
								<td class="tb_rank">ลำดับ</td>
								<td class="tb_player">นักฟุตบอล</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_point">ประตูรวม(จุดโทษ)</td>
							</tr>
						</thead>
						<tbody><tr>
					<td> 1</td>
					<td style="text-align:left;">ซลาตัน อิบราฮิโมวิช</td>
					<td>แมนเชสเตอร์ ยูไนเต็ด</td>
					<td>3(1)</td>
				</tr><tr>
					<td>2</td>
					<td style="text-align:left;">เซร์คีโอ อะกูเอโร</td>
					<td>แมนเชสเตอร์ ซิตี้</td>
					<td>3(2)</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">Manuel Agudo DuranNolito</td>
					<td>แมนเชสเตอร์ ซิตี้</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">ราฮีม สเตอริง</td>
					<td>แมนเชสเตอร์ ซิตี้</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">ฟิลิปเป้ คูติณโญ่</td>
					<td>ลิเวอร์พูล</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">มิคาอิล อันโตนิโอ</td>
					<td>เวสต์แฮมยูไนเต็ด</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">เอเตียนน์ กาปู</td>
					<td>วัดฟอร์ด</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">Christian Ricardo Stuani</td>
					<td>มิดเดิลสโบรห์</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">ดีเอโก้ ดา คอสต้า</td>
					<td>เชลซี</td>
					<td>2</td>
				</tr><tr>
					<td>3</td>
					<td style="text-align:left;">เลรอย เฟอร์</td>
					<td>สวอนซี ซิตี้</td>
					<td>2</td>
				</tr><tr>
					<td>11</td>
					<td style="text-align:left;">เอแดน อาซาร์</td>
					<td>เชลซี</td>
					<td>2(1)</td>
				</tr><tr>
					<td>11</td>
					<td style="text-align:left;">เจอร์เมน เดโฟ</td>
					<td>ซันเดอร์แลนด์</td>
					<td>2(1)</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">ซาโลมอน รอนดอน</td>
					<td>เวสต์ บรอมมิช อัลเบียน</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">Andre Gray</td>
					<td>เบิร์นลี่ย์</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">รอส เบรคกี้</td>
					<td>เอฟเวอร์ตัน</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">เมซุต โอซิล</td>
					<td>อาร์เซน่อล</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">คาลุม แชมเบอร์ส</td>
					<td>อาร์เซน่อล</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">เจมี วาร์ดี</td>
					<td>เลสเตอร์ ซิตี้</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">เอร์นานเดซ</td>
					<td>ฮัลล์ ซิตี้</td>
					<td>1</td>
				</tr><tr>
					<td>13</td>
					<td style="text-align:left;">Adama Diomande</td>
					<td>ฮัลล์ ซิตี้</td>
					<td>1</td>
				</tr></tbody></table>