<table class="shooter">
						<thead>
							<tr>
								<td class="tb_rank">ลำดับ</td>
								<td class="tb_player">นักฟุตบอล</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_total">รวม(จุดโทษ)</td>
							</tr>
						</thead>
						<tbody><tr>
						<td class="tb_rank"> 1</td>
						<td class="tb_player">Diogo Luis Santo</td>
						<td class="tb_team">Buriram United</td>
						<td class="tb_point">22(4)</td>
					</tr><tr>
						<td class="tb_rank">2</td>
						<td class="tb_player">Heberty Fernandes de Andrade</td>
						<td class="tb_team">Muang Thong United</td>
						<td class="tb_point">18(3)</td>
					</tr><tr>
						<td class="tb_rank">3</td>
						<td class="tb_player">Jonatan Ferreira Reis</td>
						<td class="tb_team">PT Prachuap F.C.</td>
						<td class="tb_point">17(1)</td>
					</tr><tr>
						<td class="tb_rank">4</td>
						<td class="tb_player">Nelson Bonilla</td>
						<td class="tb_team">Sukhothai FC</td>
						<td class="tb_point">17(4)</td>
					</tr><tr>
						<td class="tb_rank">5</td>
						<td class="tb_player">Sergio Gustavo Suarez Arteaga</td>
						<td class="tb_team">Port FC</td>
						<td class="tb_point">13(1)</td>
					</tr><tr>
						<td class="tb_rank">6</td>
						<td class="tb_player">Dragan Boskovic</td>
						<td class="tb_team">Port FC</td>
						<td class="tb_point">12(1)</td>
					</tr><tr>
						<td class="tb_rank">7</td>
						<td class="tb_player">Michael NDri</td>
						<td class="tb_team">Police Tero</td>
						<td class="tb_point">12(2)</td>
					</tr><tr>
						<td class="tb_rank">8</td>
						<td class="tb_player">Lukian Araujo de Almeida</td>
						<td class="tb_team">Pattaya United</td>
						<td class="tb_point">12(4)</td>
					</tr><tr>
						<td class="tb_rank">9</td>
						<td class="tb_player">Lonsana Doumbouya</td>
						<td class="tb_team">PT Prachuap F.C.</td>
						<td class="tb_point">11(2)</td>
					</tr><tr>
						<td class="tb_rank">10</td>
						<td class="tb_player">Robson dos Santos Fernandes</td>
						<td class="tb_team">Bangkok United FC</td>
						<td class="tb_point">10</td>
					</tr></tbody></table>