<table class="shooter">
						<thead>
							<tr>
								<td class="tb_rank">ลำดับ</td>
								<td class="tb_player">นักฟุตบอล</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_total">รวม(จุดโทษ)</td>
							</tr>
						</thead>
						<tbody><tr>
						<td class="tb_rank"> 1</td>
						<td class="tb_player">Lionel Andres Messi Cuccittini</td>
						<td class="tb_team">Barcelona</td>
						<td class="tb_point">34(2)</td>
					</tr><tr>
						<td class="tb_rank">2</td>
						<td class="tb_player">Cristiano Ronaldo dos Santos Aveiro</td>
						<td class="tb_team">Real Madrid</td>
						<td class="tb_point">26(3)</td>
					</tr><tr>
						<td class="tb_rank">3</td>
						<td class="tb_player">Luis Suarez</td>
						<td class="tb_team">Barcelona</td>
						<td class="tb_point">25(1)</td>
					</tr><tr>
						<td class="tb_rank">4</td>
						<td class="tb_player">Iago Aspas Juncal</td>
						<td class="tb_team">Celta Vigo</td>
						<td class="tb_point">22(2)</td>
					</tr><tr>
						<td class="tb_rank">5</td>
						<td class="tb_player">Christian Ricardo Stuani</td>
						<td class="tb_team">Girona</td>
						<td class="tb_point">21(5)</td>
					</tr><tr>
						<td class="tb_rank">6</td>
						<td class="tb_player">Antoine Griezmann</td>
						<td class="tb_team">Atletico Madrid</td>
						<td class="tb_point">19(2)</td>
					</tr><tr>
						<td class="tb_rank">7</td>
						<td class="tb_player">Maximiliano Gomez GonzalezMaxi Gomez</td>
						<td class="tb_team">Celta Vigo</td>
						<td class="tb_point">17</td>
					</tr><tr>
						<td class="tb_rank">8</td>
						<td class="tb_player">Gareth Bale</td>
						<td class="tb_team">Real Madrid</td>
						<td class="tb_point">16(1)</td>
					</tr><tr>
						<td class="tb_rank">8</td>
						<td class="tb_player">Rodrigo Moreno MachadoRodri</td>
						<td class="tb_team">Valencia</td>
						<td class="tb_point">16(1)</td>
					</tr><tr>
						<td class="tb_rank">8</td>
						<td class="tb_player">Gerard Moreno Balaguero</td>
						<td class="tb_team">Espanyol</td>
						<td class="tb_point">16(1)</td>
					</tr></tbody></table>