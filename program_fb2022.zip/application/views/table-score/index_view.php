<div class="col">
  <h3 class="f-prompt">ตารางคะแนนลีกหลัก</h3>
  <a data-toggle="collapse" href="#league_92" role="button" aria-expanded="false" aria-controls="league_92">
    <h3 class="f-oswald"><i class="fas fa-plus-circle"></i> English Premier League</h3>
  </a>
  <?php $this->load->view('table-score/cache/table_mini_92') ?>
</div>
<div class="col">
  <a data-toggle="collapse" href="#league_85" role="button" aria-expanded="false" aria-controls="league_85">
    <h3 class="f-oswald"><i class="fas fa-plus-circle"></i> La Liga Santander</h3>
  </a>
  <?php $this->load->view('table-score/cache/table_mini_85') ?>
</div>
<div class="col">
  <a data-toggle="collapse" href="#league_39" role="button" aria-expanded="false" aria-controls="league_39">
    <h3 class="f-oswald"><i class="fas fa-plus-circle"></i> Bundesliga</h3>
  </a>
  <?php $this->load->view('table-score/cache/table_mini_39') ?>
</div>
<div class="col">
  <a data-toggle="collapse" href="#league_34" role="button" aria-expanded="false" aria-controls="league_34">
    <h3 class="f-oswald"><i class="fas fa-plus-circle"></i> Serie A Italy</h3>
  </a>
  <?php $this->load->view('table-score/cache/table_mini_34') ?>
</div>
<div class="col">
  <a data-toggle="collapse" href="#league_93" role="button" aria-expanded="false" aria-controls="league_93">
    <h3 class="f-oswald"><i class="fas fa-plus-circle"></i> Ligue 1 France</h3>
  </a>
  <?php $this->load->view('table-score/cache/table_mini_93') ?>
</div>
<div class="col">
  <a data-toggle="collapse" href="#league_722" role="button" aria-expanded="false" aria-controls="league_722">
    <h3 class="f-oswald"><i class="fas fa-plus-circle"></i> Thai League</h3>
  </a>
  <?php $this->load->view('table-score/cache/table_mini_722') ?>
</div>