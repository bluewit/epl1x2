<table class="standing">
						<thead>
							<tr class="roll_team">
								<td class="tb_rank">อันดับ</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_match">แข่ง</td>
								<td class="tb_win">ชนะ</td>
								<td class="tb_draw">เสมอ</td>
								<td class="tb_lost">แพ้</td>
								<td class="tb_ga">ได้</td>
								<td class="tb_gd">เสีย</td>
								<td class="tb_point">คะแนน</td>
							</tr>
						</thead>
						<tbody><tr class="roll_point">
						<td class="tb_rank">1</td>
						<td class="tb_team"></td>
						<td class="tb_match"></td>
						<td class="tb_win"></td>
						<td class="tb_draw"></td>
						<td class="tb_lost"></td>
						<td class="tb_ga"></td>
						<td class="tb_gd"></td>
						<td class="tb_point"></td>
					</tr></tbody>
				</table>