<div class="collapse show" id="league_722">
									<div class="card">
									  <div class="leagueranking">
										<div class="posrank f-oswald">NO</div>
										<div class="userrank f-oswald">TEAM</div>
										<div class="numrank f-oswald">P</div>
										<div class="ptsrank f-oswald">PTS</div>
									  </div><div class="leagueranking">
						<div class="posrank">1</div>
						<div class="userrank"></div>
						<div class="numrank"></div>
						<div class="ptsrank"></div>
					</div></div></div>