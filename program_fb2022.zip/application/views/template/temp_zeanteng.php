<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>เกมส์ เซียน บอล EPL</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Oswald|Prompt" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo base_url('assets/css/mystyle.css') ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/css/price_table.css') ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/css/sbobet_fetcher.css') ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweet-alert.css') ?>" />
<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js"></script>
<script src="https://rawgit.com/tobia/Pause/master/jquery.pause.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="<?php echo base_url('assets/plugins/loadingoverlay/loadingoverlay.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-sweetalert/sweet-alert.min.js') ?>"></script>
<!-- Datatables-->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
</head>
<body>
<section class="container-fluid bg-pm">
	<div class="bg-player">
    <nav class="navbar navbar-expand-sm navbar-dark">
      <a class="navbar-brand head-logo" href="<?php echo site_url() ?>"><img src="<?php echo base_url('images/pl-logo-lion.svg') ?>" alt="Premier League" width="50%">	
      <span class="d-none d-sm-inline fz-10">EPL1x2.COM</span>
      </a>
    </nav>
    </div>
</section>
<section class="container-fluid">
  <div class="row">
    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-xs-12">
      <?php //include 'include/leaugescore.php';?>
      <?php echo $Content ?>
    </div>    
    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-xs-12">
    	<?php if(isset($rs_teamded)){ ?>
    	<div class="col">
          <h3 class="f-prompt"><i class="fas fa-chart-line fz-15"></i>
          5 ทีมเด็ด
          </h3>        
        </div>
        <div class="col">
          <div class="divranking bg-white">
            <div class="numrank f-oswald">อันดับ</div>
            <div class="userrank f-oswald">ทีม</div>
            <div class="ptsrank f-oswald">คนเลือก</div>
          </div>
          <?php $i=1; foreach($rs_teamded->result() as $row){ ?>
          <div class="divranking">
            <div class="numrank"><?php echo $i++ ?></div>
            <div class="userrank"><?php echo $row->club_name ?></div>
            <div class="ptsrank"><?php echo $row->tengnum ?></div>
          </div>
          <?php } ?>
        </div>
        <?php } ?>
        
        <?php if(isset($rs_matchalded)){ ?>
    	<div class="col">
          <h3 class="f-prompt"><i class="fas fa-chart-line fz-15"></i>
          5 คู่เสมอ เด็ด
          </h3>        
        </div>
        <div class="col">
          <div class="divranking bg-white">
            <div class="numrank f-oswald">อันดับ</div>
            <div class="userrank f-oswald">คู่</div>
            <div class="ptsrank f-oswald">คนเลือก</div>
          </div>
          <?php $i=1; foreach($rs_matchalded->result() as $row){ ?>
          <div class="divranking" style="height: 40px;">
            <div class="numrank"><?php echo $i++ ?></div>
            <div class="userrank" title="<?php echo $row->matchvs ?>"><img src="<?php echo base_url('images/uploads/S/'.$row->club_home_image) ?>"> vs <img src="<?php echo base_url('images/uploads/S/'.$row->club_away_image) ?>"></div>
            <div class="ptsrank"><?php echo $row->tengnum ?></div>
          </div>
          <?php } ?>
        </div>
        <?php } ?>
        
    	<?php if(isset($rs_memberranking)){ ?>
    	<div class="col">
          <h3 class="f-prompt"><i class="fas fa-chart-line fz-15"></i>
          5 อันดับ เซียน
          <a href="<?php echo site_url('zeanteng/list-zean') ?>"><button type="button" class="btn btn-outline-dark btn-sm fz-05">ดูทั้งหมด</button></a>
          </h3>
        
        </div>
        <div class="col">
          <div class="divranking bg-white">
            <div class="numrank f-oswald">อันดับ</div>
            <div class="userrank f-oswald">ชื่อ</div>
            <div class="ptsrank f-oswald">คะแนน</div>
          </div>
          <?php $i=1; foreach($rs_memberranking->result() as $row){ ?>
          <div class="divranking">
            <div class="numrank"><?php echo $i++ ?></div>
            <a href="" data-toggle="modal" data-target="#list-month-teng" data-id="<?php echo $row->member_id ?>" title="ดูรายการที่เล่น"><div class="userrank"><?php echo $row->nickname ?></div></a>
            <div class="ptsrank"><?php echo floatval($row->teng_score) ?></div>
          </div>
          <?php } ?>
        </div>
        <?php } ?>
    </div>
  </div>
</section>
<div class="container-fluid bg-pm1" style="padding:10px 0px 1px 0px; margin-top:20px">
  <div class="col text-center">
    <p class="fc-black"> &copy Copy right reserve epl1x2.com</p>
  </div>
</div>
</body>
</html>