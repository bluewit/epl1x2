<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include_once(dirname(__FILE__).'/Ad_manage.php');

class Table_score extends Ad_manage{
	
	public function __construct(){
		parent::__construct();
		//$this->check_admin_login();
		$this->load->library('Teamtable');
	}

	/*public function index(){
		$Content['tables'] = array(
		'พรีเมียร์ลีก'=>'92',
		'ลาลีก้า' =>'85',
		'บุนเดสลีกา' =>'39',
		'กัลโช่ เซเรีย อา' =>'34',
		'ลีกเอิง' =>'93',
		'ไทยพรีเมียร์ลีก' =>'722',
		);
		$data['Content'] = $this->load->view('table-score/table_cache', $Content, TRUE);
		$this->load->view('template/temp_football', $data);
	}*/
	
	public function update($leage_id=NULL){
		if(!$leage_id){
			$leage_id =$this->input->post('leage_id');
		}
		
			$res = $this->teamtable->get_table($leage_id);
			
			if(!$res){
				echo 'ดึงข้อมูลไม่ได้ขณะนี้';
				exit;
			}
			
			$teams = $this->teamtable->teams($res);
			$matches = $this->teamtable->matches($res);
			$win = $this->teamtable->win($res);
			$drawn = $this->teamtable->drawn($res);
			$lost = $this->teamtable->lost($res);
			$goal_for = $this->teamtable->goal_for($res);
			$goal_against = $this->teamtable->goal_against($res);
			$pts = $this->teamtable->pts($res);
			
			$cache = '<table class="standing">
						<thead>
							<tr class="roll_team">
								<td class="tb_rank">อันดับ</td>
								<td class="tb_team">ทีม</td>
								<td class="tb_match">แข่ง</td>
								<td class="tb_win">ชนะ</td>
								<td class="tb_draw">เสมอ</td>
								<td class="tb_lost">แพ้</td>
								<td class="tb_ga">ได้</td>
								<td class="tb_gd">เสีย</td>
								<td class="tb_point">คะแนน</td>
							</tr>
						</thead>
						<tbody>';
						
			$cache_mini = '<div class="collapse show" id="league_'.$leage_id.'">
									<div class="card">
									  <div class="leagueranking">
										<div class="posrank f-oswald">NO</div>
										<div class="userrank f-oswald">TEAM</div>
										<div class="numrank f-oswald">P</div>
										<div class="ptsrank f-oswald">PTS</div>
									  </div>';
			
			$i=1;
			foreach($teams AS $index=> $team){
				$cache.='<tr class="roll_point">
						<td class="tb_rank">'.$i.'</td>
						<td class="tb_team">'.trim($team).'</td>
						<td class="tb_match">'.trim($matches[$index]).'</td>
						<td class="tb_win">'.trim($win[$index]).'</td>
						<td class="tb_draw">'.trim($drawn[$index]).'</td>
						<td class="tb_lost">'.trim($lost[$index]).'</td>
						<td class="tb_ga">'.trim($goal_for[$index]).'</td>
						<td class="tb_gd">'.trim($goal_against[$index]).'</td>
						<td class="tb_point">'.trim($pts[$index]).'</td>
					</tr>'	;
					
					//if($i <=10){				
					$cache_mini.='<div class="leagueranking">
						<div class="posrank">'.$i.'</div>
						<div class="userrank">'.trim($team).'</div>
						<div class="numrank">'.trim($matches[$index]).'</div>
						<div class="ptsrank">'.trim($pts[$index]).'</div>
					</div>'	;
					//} //if เอาทั้งหมด
					$i++;
			}
			$cache .= '</tbody>
				</table>';
				
			$cache_mini .= '</div></div>';
			$path = APPPATH.'views/table-score/cache/table_'.$leage_id.'.php';
			write_file($path,$cache);
			
			$path_mini = APPPATH.'views/table-score/cache/table_mini_'.$leage_id.'.php';
			write_file($path_mini,$cache_mini);
			echo '<meta charset="utf-8"/><span style="color:green">อับเดท OK</span>';
						
	}
		
	//+ auto update form cron job
	public function auto_update(){
		$tables = array('92','85','39','34','93','722');
		foreach($tables AS $table){
			$this->update($table);
		}		
	}
			
}